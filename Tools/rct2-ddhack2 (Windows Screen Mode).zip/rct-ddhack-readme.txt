RollerCoaster Tycoon 2 Windowed Mode Hack
=========================================

This is a fork of ddhack specifically made for running RollerCoaster Tycoon 2
in windowed mode without having to fuss around with VMs and stuff like that. It
also can prevent the cursor from leaving the window for moving the camera. (see
the ddhack.ini file for details.)

Bugs
----

* When starting the game or changing the resolution in game, after a couple
  seconds the screen moves to the upper right corner on its own. This only
  seems to happen that one time though.
