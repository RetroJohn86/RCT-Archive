export default {
    input: './src/index.js',
    output: {
        format: 'iife'
    }
};