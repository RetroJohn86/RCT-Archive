
var Message = "Hello World";

// Make sure to export what you wish to import in another file.
export default Message;