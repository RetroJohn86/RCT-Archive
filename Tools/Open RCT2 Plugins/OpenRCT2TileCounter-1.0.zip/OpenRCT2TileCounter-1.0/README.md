# OpenRCT2 Tile Counter

This plugin for Open RCT2 allows you to count tiles with a specific landtype.

![Screenshot](https://github.com/autosysops/OpenRCT2TileCounter/raw/main/screenshot.png "Screenshot")

## Usage

Download the sourcecode release or the .js file from this repository.
Copy the ParkMessageManager.js file to your OpenRCT2\plugin folder.
In game click the park map menu item, there you will see the option "Count Tiles".

## Changelog

1.0 - Initial version.
