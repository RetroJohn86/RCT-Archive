
enum UISortOrder {
    None = "none",
    Ascending = "ascending",
    Descending = "descending"
}