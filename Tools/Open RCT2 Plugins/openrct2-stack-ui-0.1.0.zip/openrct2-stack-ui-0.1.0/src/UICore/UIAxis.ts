
enum UIAxis {
    Vertical,
    Horizontal
}