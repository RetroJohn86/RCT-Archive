
interface UIOptionalRange {
    min?: number
    max?: number
}