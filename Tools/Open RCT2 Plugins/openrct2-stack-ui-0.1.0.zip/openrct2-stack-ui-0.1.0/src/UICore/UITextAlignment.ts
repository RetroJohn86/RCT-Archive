
enum UITextAlignment {
    Left = "left",
    Center = "centred"
}