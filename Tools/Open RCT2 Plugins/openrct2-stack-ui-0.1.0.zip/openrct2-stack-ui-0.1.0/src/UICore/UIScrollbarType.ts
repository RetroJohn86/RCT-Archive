
enum UIScrollbarType {
    None = "none",
    Vertical = "vertical",
    Horizontal = "horizontal",
    both = "both"
}