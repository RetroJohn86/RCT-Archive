/**
 * The degree of rotation of the screen displayed by the viewport.
 */
 enum UIViewportAngle {
    A0, A90, A180, A270
}
