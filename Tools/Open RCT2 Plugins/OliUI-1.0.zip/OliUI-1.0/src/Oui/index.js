
import * as Oui from "./NameSpace";
/**
 * The namespace for OliUI.
 * @namespace
 */
export default Oui;