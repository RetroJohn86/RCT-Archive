# openrct2-waittime
Sets the minimum and maximum wait times to a specific value for all newly-created rides.
Also sets better default names for most rides to save YOU time!  

To install, download the JS file and store it in the plugins folder of your openrct2 installation.
