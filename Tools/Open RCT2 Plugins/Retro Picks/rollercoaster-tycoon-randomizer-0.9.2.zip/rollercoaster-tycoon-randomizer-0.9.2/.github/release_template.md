[//]: # "find+replace VERSION)</details></details>VERSION with the version, example: v0.8"

RollerCoaster Tycoon Randomizer mod for RCT1 and RCT2 inside of [OpenRCT2](https://openrct2.org/).

You'll need OpenRCT2 v0.4.5 or later from https://openrct2.org/downloads/releases/latest

Copy [the `rctrando.js` file](https://github.com/Die4Ever/rollercoaster-tycoon-randomizer/releases/download/VERSION)</details></details>VERSION/rctrando.js) into the OpenRCT2 plugin folder, which is usually `%USERPROFILE%\Documents\OpenRCT2\plugin\`

View [the full README here](https://github.com/Die4Ever/rollercoaster-tycoon-randomizer#readme).

## VERSION)</details></details>VERSION Changes

*

Join the [Discord discussion here](https://discord.gg/jjfKT9nYDR) or follow me on [Twitter @Die4EverDM](https://twitter.com/Die4EverDM)
