# ParkFenceManager
**Remove** or **Restore** the park fences in a park.

This is a way easier and faster way of changing the visibility of park fences without using the tile inspector.

### Put the ParkFences.js file in your plugins folder.

This plugin allows you to either remove all your back fences or restore all your park fences.

![Ingame Window](http://file.willby.info/parkfencemanager.png)

Note that this plugin does not let you move your park boundries, it is completely visual.
