# Guest Limit
OpenRCT2 plugin for limiting the amount of guests in a park.

<ol>
<li>Put the .js file in OpenRCT2's plugin folder</li>
<li>Start OpenRCT2 and open the plugin</li>
<li>Set a limit value</li>
<li>Choose whether the limit value should be compared to the number of guests on the map or the number of guests in the park</li>
<li>Enable the limit</li>
</ol>
