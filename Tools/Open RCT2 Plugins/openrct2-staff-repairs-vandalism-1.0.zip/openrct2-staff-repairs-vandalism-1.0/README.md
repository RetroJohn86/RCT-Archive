# Staff Repairs Vandalism (gorilla not included)

You paid for the whole security guard you better make use of the security guard!

---

![image](https://github.com/RickHuizing/openrct2-staff-repairs-vandalism/blob/e3efc36587f624cea9d3d65867acc6a77a1729f0/repair_cropped_loop.gif)

---
### Instalation

Add `staff-repairs-vandalism.js` to your plugin folder for OpenRCT2.

Plugin folder found at `~/Documents/OpenRCT2/plugin.`


Alternatively, add `staff-repairs-vandalism-crazy-gorillas.js` to include crazy gorillas. Do not include both!

---
