Put the `openrct2.d.ts` file in this folder.

You can take it from a OpenRCT2 installation or download it from here:

https://raw.githubusercontent.com/OpenRCT2/OpenRCT2/develop/distribution/openrct2.d.ts

For more information, please read the [README.md](../README.md).