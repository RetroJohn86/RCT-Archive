export const colourIds: { [key: string]: number } = {
  grey: 1,
  brightGreen: 14,
  yellow: 18,
  brightRed: 28,
  transparent: 54,
};
