export interface TrackElementPosition {
  position: CoordsXYZ;
  element: TrackElement;
}
