/**
 * 1 = low, 2 = moderate, 3 = excessive
 */
export type ForceLevel = 1 | 2 | 3;
