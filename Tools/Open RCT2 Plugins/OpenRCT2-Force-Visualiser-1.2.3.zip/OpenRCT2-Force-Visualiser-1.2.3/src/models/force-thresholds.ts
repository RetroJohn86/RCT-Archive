import { ForceThreshold } from "./force-threshold";

export interface ForceThresholds {
  moderate: ForceThreshold;
  excessive: ForceThreshold;
}
