export interface ForceColours {
  low: number;
  moderate: number;
  excessive: number;
  hideSupports: boolean;
}
