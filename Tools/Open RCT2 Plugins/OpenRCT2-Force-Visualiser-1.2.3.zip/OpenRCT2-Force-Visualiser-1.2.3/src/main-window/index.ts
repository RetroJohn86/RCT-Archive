export { openMainWindow } from "./open-main-window";
