# OpenRCT2 Litte Bugs v1.0
* Guests will cause extreme litter to your park in OpenRCT2

![trashypeeps](https://github.com/nodigit/OpenRCT2-Litter-Bugs/assets/6858129/34f9a4f8-a0fa-4bd0-b8a2-65ae240b9ff0)

### How to use
![litterbugsmenu](https://github.com/nodigit/OpenRCT2-Litter-Bugs/assets/6858129/9f6fc23f-6562-4919-9179-92187c0c73f8)


### Installation

To install, simply place the .js file into the **C:\Users\Documents\OpenRCT2\plugin** folder
