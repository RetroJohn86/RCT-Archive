# Purple!
A plugin for OpenRCT2 that turns everything possible in the park purple! Yes, this is a necessity to enjoy the game

How to install: Simply place the Purple!.js file in the OpenRCT2 Plugins folder

This project was a learning project on my end, with the end goal being fluent enough to help create an Archipelago plugin for the Archipelago multi world randomizer system. If you find any bugs, I'll try to get them resolved as soon as possible. Maybe. Future Colby will keep what promises he wants to.
