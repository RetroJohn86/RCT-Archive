Put the `openrct2.d.ts` file in this folder.

You can take it from a OpenRCT2 installation or [download it from here](https://raw.githubusercontent.com/OpenRCT2/OpenRCT2/v0.4.7/distribution/openrct2.d.ts).

For more information, please read the [CONTRIBUTING.md](docs/CONTRIBUTING.md).
