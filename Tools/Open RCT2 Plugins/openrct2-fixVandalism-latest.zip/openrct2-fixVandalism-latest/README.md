# openrct2-fixVandalism
Fixes Vandalism in OpenRCT2
