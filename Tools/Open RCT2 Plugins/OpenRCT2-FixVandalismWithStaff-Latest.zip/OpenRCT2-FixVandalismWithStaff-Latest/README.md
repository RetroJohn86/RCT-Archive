# OpenRCT2-FixVandalismWithStaff
An OpenRCT2 plugin that enables you to fix vandalized path additions with selected staff
