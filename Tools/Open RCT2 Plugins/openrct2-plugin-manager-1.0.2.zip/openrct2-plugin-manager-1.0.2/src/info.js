export const name = "openrct-plugin-manager";
export const version = "1.0.2";
export const type = "intransient";
export const license = "MIT";

export const authors = ["Harry Hopkinson"];

export const targetApiVersion = 81;
