let OPENRCT2_PATH = "";

export { OPENRCT2_PATH };
