Place in `OpenRCT2\plugin` directory.

Every 6 (default) in-game days, this script will run and find every empty queue-line tile and buy/place a TV on the tile.

![settings window](https://github.com/KiameV/openrct2.mod.queuetv/blob/master/img.png?raw=true)

Thanks to Tubbo's [Benchwarmer](https://github.com/tubbo/openrct2-benchwarmer) mod for the idea and starting place for this mod.
