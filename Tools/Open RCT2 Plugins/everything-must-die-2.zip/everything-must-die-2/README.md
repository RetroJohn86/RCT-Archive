# “Everything must die!”

A collection of features to wreak havoc in your park, from vandalising path furniture to blowing up guests.

Also known as:
- “My mother didn't hug me as a child, so everything must DIE” pack.
- Violation of the Geneva conventions.

This plug-in should be put into the `plugin` directory of your OpenRCT2 folder. After that, the features will become available under the Map button.

Current features:
- Blowing up guests (“EXPLODE!”)
- Destroy path furniture
