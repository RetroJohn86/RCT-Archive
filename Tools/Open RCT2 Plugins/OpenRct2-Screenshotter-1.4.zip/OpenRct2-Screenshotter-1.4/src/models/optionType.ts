enum OptionType {
  IsEnabled = "isEnabled",
  Zoom = "zoom",
  Rotation = "rotation",
  Units = "units",
  Interval = "interval",
  Transparent = "transparent"
}
export default OptionType;
