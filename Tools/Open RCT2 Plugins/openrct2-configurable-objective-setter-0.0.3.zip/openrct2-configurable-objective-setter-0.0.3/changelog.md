# 11/6/2024 - v0.0.1

First build.
There will be bugs. Please consider yourself warned.

# 11/6/2024 - v0.0.2

Fix "Max loan price" typo. Not entirely sure how I missed that one, but it seems confusing enough to make me want to fix immediately.

# 13/6/2024 - v0.0.3

Fixed early difficulty sim abortion without trying everything. This was especially impactful for repay loan goals.