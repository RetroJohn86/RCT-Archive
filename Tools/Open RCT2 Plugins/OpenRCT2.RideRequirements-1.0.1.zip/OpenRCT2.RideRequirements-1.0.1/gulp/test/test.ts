import * as jest from 'jest';

export default async function test(): Promise<void> {
  return jest.run();
}
