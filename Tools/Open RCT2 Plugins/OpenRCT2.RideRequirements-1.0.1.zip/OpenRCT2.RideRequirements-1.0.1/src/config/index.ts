import EnvConfig from '~/config/Env';

export default new EnvConfig(process.env);
