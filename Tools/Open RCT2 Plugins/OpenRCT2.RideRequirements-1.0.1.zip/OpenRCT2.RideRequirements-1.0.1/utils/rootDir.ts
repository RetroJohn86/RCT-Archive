import process from 'process';

export default process.cwd();
