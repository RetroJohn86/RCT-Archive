# Corruption Manager
Drag area to change the visibility of elements.

Way easier and less tedious way to hide things than the Tile Inspector.

### Put the CorruptionManager.js file in your plugins folder.

This plugin allows you to drag an area out and toggle the visibility of objects/elements.

![Ingame Window](http://file.willby.info/corruptionmanager.png)

The filter will allow you to only affect specific elements.
The remove feature changes if you are adding or removing corruption.
