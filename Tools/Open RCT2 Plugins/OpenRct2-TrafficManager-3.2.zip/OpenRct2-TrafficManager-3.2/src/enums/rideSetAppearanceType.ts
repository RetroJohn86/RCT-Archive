// From RideSetAppearanceAction.h in OpenRCT2.
// Unneeded types omitted.

export enum RideSetAppearanceType
{
  VehicleColourBody = 3,
  VehicleColourTrim = 4,
  VehicleColourTernary = 5
}
