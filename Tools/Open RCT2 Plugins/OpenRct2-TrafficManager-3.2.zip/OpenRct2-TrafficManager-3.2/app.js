import { resolve } from 'path';

export default resolve(__dirname).replace(/\\/g, '/');
