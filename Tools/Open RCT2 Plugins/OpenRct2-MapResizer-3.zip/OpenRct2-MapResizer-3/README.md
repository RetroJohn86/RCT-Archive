# Map Resizer

A plugin for OpenRCT2 that allows you to adjust the size of your park map by adjusting in all four directions. [Watch a tutorial and preview here!](https://www.youtube.com/watch?v=st3Zz7CRZVM)

![mapshifter](https://github.com/fidwell/OpenRct2-MapShifter/assets/5436387/6b233e91-20b0-4537-8373-497465a4f615)

## Credits

Thanks to [Basssiiie](https://github.com/Basssiiie/) for work on the [FlexUI](https://github.com/Basssiiie/OpenRCT2-FlexUI) framework and the [TypeScript template](https://github.com/Basssiiie/OpenRCT2-Simple-Typescript-Template).
