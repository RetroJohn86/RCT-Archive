// Mack & Intamin Bobsleds
export default [
  'Alpine Bobsled',
  'Avalanche',
  'Bob',
  'Bobbahn',
  'Disaster Transport',
  'La Vibora',
  'Munich Autobahn',
  'Reptilian',
  'Rolling Thunder',
  'Sarajevo Bobsled',
  'Schweizer Bobbahn',
  "Screamin' Delta Demon",
  'Trace Du Hourra',
] as const;
