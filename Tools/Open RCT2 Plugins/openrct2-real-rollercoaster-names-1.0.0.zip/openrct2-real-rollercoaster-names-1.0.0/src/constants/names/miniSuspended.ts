// Caripro
export default [
  'Batflyer',
  'Bat Glider',
  'Hydra Fighter II',
  "Scooby's Ghoster Coaster",
  'Sky Rider',
  'Spellbreaker',
  'Vleermuis',
  "Ziggy's Blast Quest",
];
