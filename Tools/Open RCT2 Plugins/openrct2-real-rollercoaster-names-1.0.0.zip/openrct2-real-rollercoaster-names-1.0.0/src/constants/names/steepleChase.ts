export default [
  'Grand National Steeplechase',
  'Steeplechase',
  'Wacky Soap Box Racers',
] as const;
