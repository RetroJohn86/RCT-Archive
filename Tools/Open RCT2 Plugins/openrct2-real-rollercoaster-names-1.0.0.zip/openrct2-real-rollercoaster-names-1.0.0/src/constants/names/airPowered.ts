export default ['Do-Dodonpa', 'HyperSonic XLC'] as const;
