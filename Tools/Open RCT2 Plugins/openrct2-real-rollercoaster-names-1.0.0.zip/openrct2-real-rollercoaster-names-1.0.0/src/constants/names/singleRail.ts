export default [
  'Jersey Devil Coaster',
  'RailBlazer',
  'Stunt Pilot',
  'Wonder Woman Flight of Courage',
  'Wonder Woman Golden Lasso Coaster',
];
