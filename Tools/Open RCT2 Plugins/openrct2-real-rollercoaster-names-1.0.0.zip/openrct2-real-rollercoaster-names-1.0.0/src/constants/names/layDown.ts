// Vekoma flying
export default [
  'Batwing',
  'Firehawk',
  'F.L.Y.',
  'Nighthawk',
  'Stealth',
  'Stingray',
  'X-Flight',
] as const;
