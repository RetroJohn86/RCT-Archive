// Arrow Dynamics/S&S 4th dimension
export default ['X', 'X2', 'Eejanaika', 'Dinoconda'] as const;
