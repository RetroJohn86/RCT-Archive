// Intamin reverse free fall
export default ['Superman: Escape from Krypton', 'Tower of Terror II'] as const;
