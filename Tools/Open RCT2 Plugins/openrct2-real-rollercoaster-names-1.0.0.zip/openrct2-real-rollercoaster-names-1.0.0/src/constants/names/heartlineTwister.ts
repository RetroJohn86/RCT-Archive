// Togo Ultratwister
export default [
  'Ultra Coaster',
  'Ultra Twister',
  'Ultra Twister Megaton',
] as const;
