// Arrow Hyper & Morgan Hyper
export default [
  'Big One',
  'Desperado',
  'Magnum XL-200',
  'Mamba',
  'Phantom’s Revenge',
  'Steel Eel',
  'Steel Force',
  'Steel Dragon 2000',
  'Superman el Último Escape',
  'Titan MAX',
  'Wild Thing',
];
