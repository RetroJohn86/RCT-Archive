export default [
  'Chatouilleur',
  "Jack 'n' Jill Scenic",
  'Krazy Ribbon',
  'Slangebanen',
  'Social Whirl',
  'Tickler',
  'Virginia Reel',
] as const;
