// Intamin impulse
export default [
  'Flash: Vertical Velocity',
  'Legendary Twin Dragon',
  'Linear Gale',
  'Possessed',
  'Screaming Condor',
  'Steel Venom',
  'V2',
  'Wicked Twister',
] as const;
