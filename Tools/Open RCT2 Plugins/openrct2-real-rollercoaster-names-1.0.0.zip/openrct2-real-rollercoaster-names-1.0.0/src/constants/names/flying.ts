// B&M Flyer
export default [
  'Acrobat',
  'Air',
  'Crystal Wing',
  'Flying Dinosaur',
  'Galactica',
  'Harpy',
  'Manta',
  'Starry Sky Ripper',
  'Superman - Ultimate Flight',
  'Tatsu',
] as const;
