// Arrow Dynamics and Vekoma
export default [
  'Bat',
  'Big Bad Wolf',
  'Centrifuge',
  'Dreamcatcher',
  'Eagle Fortress',
  'Grampus Jet',
  'Hayabusa',
  'Iron Dragon',
  'Ninja',
  'Sky Coaster',
  'Vampire',
  'Vortex',
  'XLR-8',
] as const;
