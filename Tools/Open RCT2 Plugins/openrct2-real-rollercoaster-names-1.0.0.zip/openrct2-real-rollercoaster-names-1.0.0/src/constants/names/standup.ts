// Togo Stand up
export default [
  'Freestyle',
  'Fujin Raijin II',
  'King Cobra',
  'Milky Way',
  'Momonga Standing and Loop Coaster',
  'Pink Typhoon Standing Coaster',
  'Shockwave',
  'SkyRider',
  'Standing Coaster',
  'Star Jet',
  'Wind God Thor',
] as const;
