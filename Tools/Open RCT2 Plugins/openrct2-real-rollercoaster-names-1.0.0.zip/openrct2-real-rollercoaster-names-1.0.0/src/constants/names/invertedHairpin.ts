// Reverchon inverted thing
export default ['€uro-Coaster'] as const;
