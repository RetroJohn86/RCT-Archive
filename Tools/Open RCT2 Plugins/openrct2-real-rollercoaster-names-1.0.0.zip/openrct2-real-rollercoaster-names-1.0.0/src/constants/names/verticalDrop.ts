// B&M Dive Machine
export default [
  'Baron 1898',
  'Dive Coaster',
  'Diving Coaster',
  'Diving Machine G5',
  'Draken',
  "Dr. Diabolical's Cliffhanger",
  'Emperor',
  'Flying Apsaras in Western Region',
  'Griffon',
  'Krake',
  'Oblivion',
  'Oblivion - The Black Hole',
  'SheiKra',
  'Valkyria',
  'Valravn',
  'Yukon Striker',
] as const;
