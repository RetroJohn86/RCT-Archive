// Premier water coaster
export default ['BuzzSaw Falls', 'Vonkaputous'] as const;
