# 11/6/2024 - v0.0.1

First build.
There will be bugs. Please consider yourself warned.