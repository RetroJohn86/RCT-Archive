# CoasterCompliments
OpenRCT2 plugin that gives random compliments to the player.

<ol>
<li>Put the .js file in OpenRCT2's plugin folder</li>
<li>Start OpenRCT2</li>
<li>Receive compliments!</li>
</ol>

You can edit the .js file to add or remove compliments or to set the time between compliments.
