# openrct2-guestcolors
guest colors
colors guest shirts based on data for easy visualization