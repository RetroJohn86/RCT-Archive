# Lift Speed Maximizer

Plugin that sets lift hill speed once a day or forced.

To force a menu item has been added to map menu.

Based on <a href="https://github.com/Basssiiie/OpenRCT2-Simple-Typescript-Template">Simple OpenRCT2 plugin template with Typescript</a>