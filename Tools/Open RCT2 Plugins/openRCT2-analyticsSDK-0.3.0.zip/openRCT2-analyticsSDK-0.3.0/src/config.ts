const config = {
  pluginVersion: "0.0.2",
  dataKey: "analytics.data.storage",
  parkIdKey: "analytics.park.id",
  analyticsEventEnqueueKey: "analyticsEventEnqueue",
  analyticsFlushAndSaveKey: "analyticsFlushAndSave",
} as const;

export { config };
