export { analytics } from "./objects/analytics";
export { TrackEventProps, TrackEventType } from "./objects/analytics";
import { config } from "./config";

const dataSaveKey = config.dataKey;

export { dataSaveKey };
