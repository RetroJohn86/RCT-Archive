// Set build configuration for unit tests.
// Options: development, production
global.__BUILD_CONFIGURATION__ = "production";