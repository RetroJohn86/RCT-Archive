import ride from "./ride"
import animal from "./animal"
import fantasy from "./fantasy"
import space from "./space"
import nature from "./nature"

export default [...ride, ...animal, ...fantasy, ...space, ...nature]
