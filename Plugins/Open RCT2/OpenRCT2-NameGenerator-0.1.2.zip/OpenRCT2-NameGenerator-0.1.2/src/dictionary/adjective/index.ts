import ride from "./ride"
import emotion from "./emotion"
import verb from "./verb"
import location from "./location"

export default [...ride, ...emotion, ...verb, ...location]
