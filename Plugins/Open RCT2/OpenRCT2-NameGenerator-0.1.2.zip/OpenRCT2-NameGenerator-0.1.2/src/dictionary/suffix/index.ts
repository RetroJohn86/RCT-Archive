import letter from "./letter"
import number from "./number"
import word from "./word"

export default [...letter, ...number, ...word]
