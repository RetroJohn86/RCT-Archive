export default {
    input: './src/index.js',
    output: {
		file: './build/TwitchTools.js',
        format: 'iife'
    },
};
