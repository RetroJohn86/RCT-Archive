// eslint-disable-next-line import/prefer-default-export
export const isString = (val: unknown): val is string => typeof val === 'string';
