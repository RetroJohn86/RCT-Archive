# MaxGuestPlugin v2.1.0

# What is this plugin for?

This plugin is used to limit the number of guests that can be in a park at the same time.
This plugin is useful for parks that are of the smaler size but have a lot of guests.
Or for player that have a low-end pc but want to play the game to the fullest.
This plugin also allows for the removal of guests from the park.
This can be a specific number of guests or to the max number of guests.

# How to install this plugin?
First you need to download the plugin from the openrct2 plugin store.
Then you need to put it in the plugin folder of openrct2.
Then open the game and enjoy!

# How to use this plugin?
When you have installed the plugin you can open the plugin window by clicking on the map icon and selecting the MaxGuestPlugin.
First you see a window where you can choose to open the maxGuest window or the removeGuest window.
When you click on the maxGuest button you will see a window where you can set the max number of guests.
When you click on the removeGuest button you will see a window where you can remove guests from the park.

## MaxGuest window
In the maxGuest window you can set the max number of guests.
NOTE: this can only between 0 and 10000. 
When enabled the plugin will check every in game day if the number of guests is higher than the max number of guests.
If this is the case the plugin will automatically stop the generation of new guest.
When the number of guests is lower than the max number of guests the plugin will automatically start the generation of new guests.

## RemoveGuest window
In the removeGuest window you can remove guests from the park.
NOTE: this can only between 0 and 10000.
When clicked on the remove icom it will automatically remove the number of guests you have set.
When clicked on the remove to maxGuest button it will automatically remove the number of guests to the max number of guests.


# important notes
* This plugin CAN remove guests from the park but won't do it automatically.
* This plugin will not stop guests from leaving the park.
* This plugin will not stop guests from entering the park when disabled or under the max.
* This plugin is not always correct, it can be possible that the number of guests is higher than the max number of guests by a few guest.
* This plugin is not optimized for multiplayer, it is possible that the plugin will not work correctly in multiplayer.* This plugin will still be enaled when the game is saved and loaded.
This also means that sharing the park will result into that the pulgin is also enabled for the other person. (WORKS ONLY OF THE OTHER PERSON HAS THE PLUGIN)
* THIS PLUGIN DOES NOT WORK CORRECTLY WTIH THE LAGRE GROUP OF GUESTS CHEAT.
* USE THIS PLUGIN AT YOUR OWN RISK (THE MAKER IS NOT RESPONSIBLE FOR ANY DAMAGE TO ANY FILE/PARK).
* NOTE THAT THE REMOVE GUEST FUNCTION DOES NOT WORK WHILE PEEPS ARE ON RIDES SO KEEP THAT IN MIND.
This is because the api does not allow to remove peeps from rides. therefore is this a V2.0.0 function and its future is not guaranteed.


# Changelog
* V1.0.0: initial release
* V2.0.0: added remove guest function and some bug fixes
* V2.1.0: Added the functionallity to keep the plugin enabled even when the game is saved and loaded.

# Version numbering
* V*1* Major changes
* V1.*1* Minor changes like bug fixes in the same major version
* V1.1.*1* Bug fixes in the same minor version
