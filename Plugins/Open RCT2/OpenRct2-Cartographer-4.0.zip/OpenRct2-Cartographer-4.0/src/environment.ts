export const pluginVersion = "4.0.0";
export const pluginName = "Cartographer";
export const pluginAuthors = ["fidwell"];
export const isUiAvailable = (typeof ui !== "undefined");
export const namespace = "cartographer";
