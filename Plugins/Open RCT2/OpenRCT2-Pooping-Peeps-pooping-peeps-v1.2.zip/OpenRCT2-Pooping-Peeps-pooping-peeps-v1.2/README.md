### Pooping Peeps v1.10

![pooping-peeps](https://github.com/nodigit/OpenRCT2-pooping-peeps/assets/6858129/0e880176-b45e-4acc-b74d-d00e651e144c)

- Peeps will randomly defecate on the path once they reach their threshold
- Guests are more likely to "potty dance" when they need to use the bathroom
- Guest that soil their pants will instantly become angry
- Guests will use bathroom more frequently

### Update notes for Pooping Peeps v1.12

- Added in-game menu to enable/disable the plugin. Menu is located under the Map button.
  
![poop-menu](https://github.com/nodigit/OpenRCT2-Pooping-Peeps/assets/6858129/a4aa6d0a-136a-4b36-980b-c332d282bd25)


### Update notes for Pooping Peeps v1.10

- Fixed an issue with the fast forward/pause buttons not working. 
- Added monthly alerts for when too many "incidents" occur in your park

### Installation

To install, simply place the .js file into the **C:\Users\Documents\OpenRCT2\plugin** folder
