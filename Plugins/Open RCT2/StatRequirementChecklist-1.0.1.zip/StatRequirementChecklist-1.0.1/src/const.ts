export const PLUGIN_CONTEXT_KEY = 'AT41.StatRequirementChecklist.Options';
export const PLUGIN_WINDOW_CLASSIFICATION = 'Stat Requirement Window';
