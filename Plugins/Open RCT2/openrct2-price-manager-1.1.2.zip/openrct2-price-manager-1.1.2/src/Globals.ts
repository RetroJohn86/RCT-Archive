const ACTION = "price-manager-action";
const PREFIX = "price_manager.";

export {
    ACTION,
    PREFIX,
}
