const PluginNamespace = `RidePainter`
export default PluginNamespace
