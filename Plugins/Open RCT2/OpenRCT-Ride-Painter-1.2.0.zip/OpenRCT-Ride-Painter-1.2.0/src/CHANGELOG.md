Changes in v 0.1.2

Completed:
Features
_ Add a column to show the first 15 selected rides.
_ Add button to scroll main viewport to selected ride
_ Add repaint button to selected ride
_ Prebuilt tracks are now painted on placement.

Under the hood: \* Refactor code to use ArrayStores

Fixes: \* Rides that start in the park aren't repainted accidentally

In progress
Feat: add undo button for most recent 3-5 paints
Feat: Theme creation & management. Ability for any user to create/delete/share/import their own custom themes.
Feat: Paginate through selected rides in right column
