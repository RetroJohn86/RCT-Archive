# RoadLines
OpenRCT2 plugin to easily create roadlines at surface level

![](https://i.imgur.com/mG7rCde.gif)

## Installation
Copy the JS file in the `build` directory from this repository to `OpenRCT2/plugin`, you can access the tools via the map toolbar.
