export default {
    input: 'build/index.js',
    output: {
        file: '../../plugin/BuildingGenerator.js',
        format: 'iife'
    }
};