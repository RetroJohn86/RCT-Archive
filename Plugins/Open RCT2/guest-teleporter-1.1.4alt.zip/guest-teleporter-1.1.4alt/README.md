# Guest Teleporter

Quickly move all guests to a selected footpath.

![Guest Teleporter](/images/demo.gif)

## Usage

1. Select the tile you want to send guests to.
2. Select the z-coordinate of the footpath you'd like.
3. Teleport!

### Known Issues

If guests are on a ride or at the front of a queue, they bug out upon teleporting and won't walk on paths, and just wander around the park.
