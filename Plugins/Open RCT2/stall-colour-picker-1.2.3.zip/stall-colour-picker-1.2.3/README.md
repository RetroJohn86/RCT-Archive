# Stall Colour Picker

A simple plugin that lets you change the colour for all your stalls at once!

![alt text](https://github.com/mrmagic2020/stall-colour-picker/blob/main/ui_new.png?raw=true)

This plug-in should be put into the `plugin` directory of your OpenRCT2 folder. After that, the features will become available under the Map button. 

Current features:
- Set Colours for all Stalls
- Toggle the "Use Random Colour" Flag for all Stalls.
- Enable Auto Colour Update for all Stalls


This plugin and readme is deeply inspired by other peoples existing plugins. This couldn't exist without them, so thank you, Gymnasiast and others.