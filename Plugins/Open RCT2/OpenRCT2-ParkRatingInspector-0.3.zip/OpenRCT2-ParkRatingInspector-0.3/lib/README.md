Placeholder file to commit this empty directory.

Place your `openrct2.d.ts` file inside this folder.
