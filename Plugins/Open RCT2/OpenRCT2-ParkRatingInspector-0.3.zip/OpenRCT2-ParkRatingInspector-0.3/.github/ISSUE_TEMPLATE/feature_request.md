---
name: Feature request
about: Suggest an idea for this plugin
title: ''
labels: 'enhancement'
---

**Idea**
Please describe what you'd like to see added or changed.

**Additional context**
Add any other context, screenshots, related information about the feature request here.
