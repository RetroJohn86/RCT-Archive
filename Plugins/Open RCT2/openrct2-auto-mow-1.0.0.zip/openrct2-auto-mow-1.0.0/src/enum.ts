export enum GrassLengths {
    MOWED,
    CLEAR_0,
    CLEAR_1,
    CLEAR_2,
    CLUMP_0,
    CLUMP_1,
    CLUMP_2,
}
