# MoveViewport
**MoveViewport** is an OpenRCT2 plugin which moves game's main viewport every n-seconds, like CCTV.  
It requires latest develop version of OpenRCT2 to run this plugin.

# Features
 * Watching a ride's entrance, exit or start position of its random station
 * Watching a random position of map
 * Rotating the screen

# Todo
 * Zooming the screen