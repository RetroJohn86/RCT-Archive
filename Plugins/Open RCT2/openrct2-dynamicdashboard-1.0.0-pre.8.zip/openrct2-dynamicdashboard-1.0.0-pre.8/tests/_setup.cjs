global.__BUILD_CONFIGURATION__ = "test"
global.__VERSION__ = ""
global.__CHANGELOG__ = ""
