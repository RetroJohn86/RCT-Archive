# Forest Nothing / Handymen Place Trees

Ever get tired of placing trees? Why not pay someone to do it for you?

Handymen will place trees and small bushes while mowing. The amount of stuff placed can be configured.
![sample](https://github.com/RickHuizing/openrct2-forest-nothing/assets/15342604/fe02e3e0-0b93-40ea-9cdd-f4f9a0e6f1fa)
## Installation

like other plugins, find your plugin folder at `Documents/OpenRCT2/plugin` and add `forest-nothing.js` to the list!


## Notes
Not tested for multiplayer. If you encounter any issues, please let me know.

scenery is loaded from the following scenery groups:
```
'rct2.scenery_group.scgtrees' - Trees 
'rct2.scenery_group.scgshrub' - Shrubs and Ornaments (statues and fountains manually removed)
```

I got the idea from someone I think on the OpenRCT2 Github, but can't seem to find their post anymore.

#### big thanks to Basssiiie for his plugin template
The template can be found at https://github.com/Basssiiie/OpenRCT2-Simple-Typescript-Template

#### another big thanks to the OpenRCT2 team, you guys are amazing