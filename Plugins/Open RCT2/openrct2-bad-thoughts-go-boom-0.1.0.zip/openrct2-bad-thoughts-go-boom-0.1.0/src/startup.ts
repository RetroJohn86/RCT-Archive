import * as guests from "./data/guests";

export function startup() {
    guests.initialize();
}
