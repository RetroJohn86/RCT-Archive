Put the `openrct2.d.ts` file in this folder. You can use a different OpenRCT2 version, but this template is set up to use v0.4.11's version:

https://raw.githubusercontent.com/OpenRCT2/OpenRCT2/v0.4.11/distribution/openrct2.d.ts
