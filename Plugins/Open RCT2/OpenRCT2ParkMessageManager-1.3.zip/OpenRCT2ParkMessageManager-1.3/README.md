# OpenRCT2 Park Message Manager

This plugin for OpenRCT2 allows you to managed the messages in the park. You can delete a single message or all the messages at once. You can also add new messages of different types. For now the plugin allows you to pick the type of message and it will show a preview image of the image which will be shown with the message. You can also select the colour of the text (which will also be previewed in the dropdown box).

![Screenshot](https://github.com/autosysops/OpenRCT2ParkMessageManager/raw/main/screenshot.png "Screenshot")

## Usage

Download the sourcecode release or the .js file from this repository.
Copy the ParkMessageManager.js file to your OpenRCT2\plugin folder.
In game click the park map menu item, there you will see the option "Manage Park Messages".

## Changelog

1.3 - Started the creation of a rich text editor so you can easily color text and make it smaller and bigger. Also added the option to see message which haven't been posted yet.

1.2 - The window now refreshes every second and new messages are shown at the bottom. Also there is a check so messages which are to big can't be posted and the message overview window now cuts of messages so they are better readable.

1.1 - Added option to select a ride or guest for the message which support it.

1.0 - Initial version.
