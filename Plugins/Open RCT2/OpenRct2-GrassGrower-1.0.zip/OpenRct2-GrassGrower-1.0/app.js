const path = require('path');

module.exports = path.resolve(__dirname).replace(/\\/g, '/');
