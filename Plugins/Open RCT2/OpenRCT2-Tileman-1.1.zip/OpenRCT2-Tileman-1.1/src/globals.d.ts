declare const __environment : string;
declare const __version : string;