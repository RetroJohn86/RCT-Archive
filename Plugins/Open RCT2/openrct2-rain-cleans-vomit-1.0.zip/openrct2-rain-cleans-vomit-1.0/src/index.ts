import main from './main';

registerPlugin({
  name: 'Rain Cleans Vomit',
  version: '1.0',
  authors: ['nickgal'],
  type: 'remote',
  licence: 'MIT',
  // minApiVersion
  // targetApiVersion
  main
});
