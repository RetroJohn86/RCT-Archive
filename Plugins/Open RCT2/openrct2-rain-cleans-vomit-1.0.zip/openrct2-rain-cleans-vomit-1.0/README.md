# openrct2-rain-cleans-vomit

An OpenRCT2 plugin that gives rain a chance to clean vomit.

### Building from source

Run `yarn build`. Plugin will be output to `dist/RainCleansVomit.js`
