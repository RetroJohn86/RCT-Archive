export const INVALID = 9
export const PATH = 1
export const PREBUILTPATH = 2
export const WALL = 0
